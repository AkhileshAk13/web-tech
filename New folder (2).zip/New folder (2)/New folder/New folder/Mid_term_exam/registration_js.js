function reg(){
var opwd=document.getElementById("password").value;
var rpwd=document.getElementById("repassword").value;
            {
                if(opwd!=rpwd)
                    alert("Passworrrd do not match")
            }
}





