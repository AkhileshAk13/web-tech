import React from 'react';
import './Side.css';
function Side({setview})
{ 
    return(
        <aside className="Side">
    <ul>
        <li onClick={()=>setview('home')}>Home</li>
        <li onClick={()=>setview('about')}>About</li>
    </ul>
    </aside>
    );
};
export default Side;


