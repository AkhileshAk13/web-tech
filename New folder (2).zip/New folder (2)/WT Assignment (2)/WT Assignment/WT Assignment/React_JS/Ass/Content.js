import React from 'react';
import './Content.css';
function Content({view})
{
    function reads()
    {
        switch(view)
        {
            case 'home':
            return<h1>This is the Home Page</h1>;

            case 'about':
            return <h1>This is About of the Website</h1>;
        }
    }
    return(
        <div className="Content">
            {reads()}
        </div>
    );
};
export default Content;


