import React from 'react';
import './Header.css';
function Header() {
  return (
    <header className="Header">
    
      <h1>This is The Heading</h1> {/* Use h1 or another tag for the heading */}
    </header>
  );
}

export default Header;
