import React,{useState} from 'react';
import Header from './Ass/Header'; 
import Content from './Ass/Content'; 
import Side from './Ass/Side'; 
import Footer from './Ass/Footer'; 

function App() {
  const[view,setview]=useState('home');
  return (
    <div>
      
      {/* Use ParentComponent here */}
      <Header />
      <Content view={view}/>
      <Side setview={setview}/>
      <Footer/>
    </div>
  );
};

export default App;
